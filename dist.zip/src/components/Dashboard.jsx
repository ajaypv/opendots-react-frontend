import React, { useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { Link, useHistory } from "react-router-dom";
import Nav from "./Nav"
import Header from "./Header";
import Dots from "./DotConnect"
import OpenStage from "./Stage";
import "../styles/Dashboard.css";

export default function Dashboard() {
  const [currentComponent, setCurrentComponent] = useState('ComponentA');
  console.log("compomnrt", currentComponent)

  const [error, setError] = useState("");
  const { currentUser, logout } = useAuth();
  const history = useHistory()

  const handleComponentChange = (componentName) => {
    setCurrentComponent(componentName);
    console.log("called")
    
  }

  async function handleLogout() {
    setError("");

    try {
      await logout();
      history.push("/signup")
    } catch {
      setError("Failed to log out");
    }
  }

  return (
    <>
     <Nav onComponentChange={handleComponentChange} />
     {currentComponent === 'ComponentB' && <Dots/>}
      {currentComponent === 'ComponentA' && <OpenStage />}
    </>
  );
}
