import React, { useState,useRef,useEffect } from "react";

const servers = {
    iceServers: [
      {
        urls: ["stun:stun1.1.google.com:19302", "stun:stun2.1.google.com:19302"],
      },
    ],
  };
  import { io } from "socket.io-client";

const socket = io("http://localhost:3000");
export default function Dots() {
  const [currentComponent, setCurrentComponent] = useState('ComponentA');

  const [error, setError] = useState("");
  const [peerConnection, setPeerConnection] = useState(null);
  const [localStream, setLocalStream] = useState(null);
  const [remoteStream, setRemoteStream] = useState(null);
  const [socketId, setSocketId] = useState("");

  const user1Video = useRef(null);
  const user2Video = useRef(null);
  const sdpKeyInput = useRef(null);

  useEffect(() => {
    const init = async () => {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });
      setLocalStream(stream);
      user1Video.current.srcObject = stream;
    };
    init();
  }, []);

  useEffect(() => {
    socket.on("connect", () => {
      setSocketId(socket.id);
    });

    socket.on("reciveingOffer", async (message, to) => {
      createPeerConnection("answer-sdp", to);
      let offer = message;
      if (!offer) return alert("Retrieve offer from peer first...");
      offer = JSON.parse(offer);
      await peerConnection.setRemoteDescription(offer);
      let answer = await peerConnection.createAnswer();
      await peerConnection.setLocalDescription(answer);
      socket.emit("sendingAnswer", JSON.stringify(answer), to);
    });

    socket.on("reciveingAnswer", (answer) => {
      answer = JSON.parse(answer);
      if (!peerConnection.currentRemoteDescription) {
        peerConnection.setRemoteDescription(answer);
      }
    });

    socket.on("candidate", (candidate) => {
      if (peerConnection) {
        peerConnection.addIceCandidate(candidate);
      }
    });
  }, [peerConnection]);

  const createPeerConnection = async (sdpType, to) => {
    const pc = new RTCPeerConnection(servers);
    setPeerConnection(pc);

    const stream = new MediaStream();
    setRemoteStream(stream);
    user2Video.current.srcObject = stream;

    localStream.getTracks().forEach((track) => {
      pc.addTrack(track, localStream);
    });

    pc.ontrack = async (event) => {
      event.streams[0].getTracks().forEach((track) => {
        stream.addTrack(track);
      });
    };

    pc.onicecandidate = async (event) => {
      if (event.candidate) {
        socket.emit("sendingonIcecandidate", event.candidate, to);
      }
    };
  };

  const createOffer = async () => {
    const to = sdpKeyInput.current.value;
    createPeerConnection("offer-sdp", to);
    let offer = await peerConnection.createOffer();
    await peerConnection.setLocalDescription(offer);
    socket.emit("sendingOffer", JSON.stringify(offer), to, socketId);
  };

  
  
  
  return (
    <>
    <h1>FUN DOTS PAGE</h1>
  <div id="videos">
      <video ref={user1Video} autoPlay></video>
      <video ref={user2Video} autoPlay></video>
      <input type="text" placeholder="SDP Key" ref={sdpKeyInput} />
      <button onClick={createOffer}>Create Offer</button>
    </div>
    </>
  );
}
